const express = require("express");

const testControllers = require("../controllers/testController");

const router = express.Router();
router.get("/test", testControllers.testfunct);
router.post("/test1", testControllers.testPost);
module.exports = router;
